# Project-AB

This project is a breakout game. Click the Start Game button to start. Destroy bricks to your hearts content! Don't break all of your hearts though...you only have 5 😢. Break all of your hearts and it's game over 😔. But don't worry, you can start all over again by clicking the Start game button! ✨🎉🎉🎉✨

Go to www.jazminmatos.com to play!

# Installation Instructions

Clone the repo and run 'open index.html' in the terminal.
